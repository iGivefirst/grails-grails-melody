javamelody{
    disabled = false
}