javamelody.disabled = false
javamelody.'displayed-counters' = 'http,sql,error,log,spring'